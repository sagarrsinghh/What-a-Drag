import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import SidePanel from './SidePanel';
import { useCart } from '../context/CartContext';
import { useLikes } from '../context/LikesContext';
import { useAuth } from '../context/AuthContext';

// --- ICONS ---
const SearchIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
    </svg>
);
const UserIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
    </svg>
);
const CartIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 1 0-7.5 0v4.5m11.356-1.993 1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 0 1-1.12-1.243l1.264-12A1.125 1.125 0 0 1 5.513 7.5h12.974c.576 0 1.059.435 1.119 1.007ZM8.625 10.5a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm7.5 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
    </svg>
);
const HeartIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z" />
    </svg>
);
const XIcon = ({ className = "w-5 h-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
    </svg>
);

// --- ANIMATED BUTTON COMPONENT ---
const NavButton = ({ icon, onClick, showBadge, className = "" }) => (
    <motion.button
        onClick={onClick}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={`w-10 h-10 flex items-center justify-center rounded-full bg-white border border-transparent hover:border-[#E5E5E5] hover:bg-[#FAFAFA] transition-colors text-[#1A1A1A] relative ${className}`}
    >
        {icon}
        {showBadge && (
            <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-1 right-1 w-2 h-2 bg-[#9B4819] rounded-full border border-white"
            />
        )}
    </motion.button>
);

const Navbar = () => {
    const navigate = useNavigate();
    const location = useLocation();

    // Auth & Context
    const { user, logout } = useAuth();
    const { isCartOpen, setIsCartOpen, cart, cartCount, removeFromCart, cartTotal } = useCart();
    const { likedItems } = useLikes();

    // Local State
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

    const searchInputRef = useRef(null);
    const profileMenuRef = useRef(null);

    // Scroll Reset on Logo Click
    const handleLogoClick = (e) => {
        e.preventDefault();
        window.scrollTo(0, 0);
        navigate('/');
    };

    // Close menus on click outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (profileMenuRef.current && !profileMenuRef.current.contains(event.target)) {
                setIsProfileMenuOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    // Focus search input
    useEffect(() => {
        if (isSearchOpen && searchInputRef.current) {
            searchInputRef.current.focus();
        }
    }, [isSearchOpen]);

    const handleSearchSubmit = (e) => {
        e.preventDefault();
        if (searchQuery.trim()) {
            navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
            setIsSearchOpen(false);
            setSearchQuery("");
        }
    };

    const handleLogout = () => {
        logout();
        setIsProfileMenuOpen(false);
        navigate('/');
    };

    const isActive = (path) => location.pathname.includes(path);

    return (
        <>
            <motion.nav
                initial={{ y: -100 }}
                animate={{ y: 0 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="fixed top-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-md border-b border-[#E5E5E5] py-3"
            >
                <div className="max-w-7xl mx-auto px-6 md:px-8 h-12 flex items-center justify-between relative">

                    {/* 1. LEFT: LOGO */}
                    <Link to="/" onClick={handleLogoClick} className="text-2xl font-black tracking-tighter text-[#1A1A1A] cursor-pointer z-50">
                        DRAG<span className="text-[#9B4819]">.</span>
                    </Link>

                    {/* 2. CENTER: NAVIGATION & SEARCH INPUT */}
                    <div className="absolute left-1/2 -translate-x-1/2 w-full max-w-sm flex justify-center">
                        <AnimatePresence mode="wait">
                            {!isSearchOpen ? (
                                <motion.div
                                    key="nav-links"
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: -10 }}
                                    transition={{ duration: 0.2 }}
                                    className="hidden md:flex items-center gap-6"
                                >
                                    <Link to="/category/men" className={`text-[11px] font-bold uppercase tracking-[0.2em] transition-colors ${isActive('/men') ? 'text-[#9B4819]' : 'text-[#777] hover:text-black'}`}>Men</Link>
                                    <Link to="/category/women" className={`text-[11px] font-bold uppercase tracking-[0.2em] transition-colors ${isActive('/women') ? 'text-[#9B4819]' : 'text-[#777] hover:text-black'}`}>Women</Link>
                                </motion.div>
                            ) : (
                                <motion.form
                                    key="search-form"
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.95 }}
                                    transition={{ duration: 0.2 }}
                                    onSubmit={handleSearchSubmit}
                                    className="relative w-full"
                                >
                                    <input
                                        ref={searchInputRef}
                                        type="text"
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        placeholder="Search..."
                                        className="w-full bg-transparent border-b-2 border-[#1A1A1A] py-2 text-sm font-bold uppercase tracking-widest text-[#1A1A1A] placeholder:text-gray-300 focus:outline-none text-center"
                                    />
                                    <button type="button" onClick={() => setIsSearchOpen(false)} className="absolute right-0 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black">
                                        <XIcon className="w-4 h-4" />
                                    </button>
                                </motion.form>
                            )}
                        </AnimatePresence>
                    </div>

                    {/* 3. RIGHT: ICONS */}
                    <div className="flex items-center gap-1 z-50">

                        {/* Search Trigger */}
                        <AnimatePresence>
                            {!isSearchOpen && (
                                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                                    <NavButton icon={<SearchIcon />} onClick={() => setIsSearchOpen(true)} />
                                </motion.div>
                            )}
                        </AnimatePresence>

                        {/* Likes */}
                        <NavButton
                            onClick={() => navigate('/likes')}
                            icon={<HeartIcon />}
                            showBadge={likedItems && likedItems.length > 0}
                        />

                        {/* Profile Logic: Displays Name if logged in */}
                        {user ? (
                            <div className="relative" ref={profileMenuRef}>
                                <motion.button
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                    onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                                    className="h-10 px-3 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors gap-2 border border-transparent hover:border-[#E5E5E5]"
                                >
                                    <UserIcon className="w-5 h-5 text-[#1A1A1A]" />
                                    {/* Displays User Name Dynamically */}
                                    <span className="hidden md:block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A]">
                                        {user?.firstName || user?.name || user?.email?.split('@')[0] || "Account"}
                                    </span>
                                </motion.button>

                                {/* Dropdown Menu */}
                                <AnimatePresence>
                                    {isProfileMenuOpen && (
                                        <motion.div
                                            initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                            animate={{ opacity: 1, y: 0, scale: 1 }}
                                            exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                            transition={{ duration: 0.2 }}
                                            className="absolute top-full right-0 mt-2 w-40 bg-white border border-[#E5E5E5] shadow-xl py-2 rounded-lg origin-top-right overflow-hidden"
                                        >
                                            <Link to="/profile" onClick={() => setIsProfileMenuOpen(false)} className="block px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-black hover:bg-gray-50">Profile</Link>
                                            
                                            <Link to="/profile" state={{ activeTab: 'orders' }} onClick={() => setIsProfileMenuOpen(false)} className="block px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-black hover:bg-gray-50">Orders</Link>
                                            
                                            <div className="h-px bg-gray-100 my-1"></div>
                                            <button onClick={handleLogout} className="w-full text-left px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-red-500 hover:bg-gray-50">Log Out</button>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        ) : (
                            <NavButton onClick={() => navigate('/login')} icon={<UserIcon />} />
                        )}

                        {/* Cart */}
                        <NavButton onClick={() => setIsCartOpen(true)} icon={<CartIcon />} showBadge={cartCount > 0} />
                    </div>
                </div>
            </motion.nav>

            {/* --- CART SIDE PANEL --- */}
            <SidePanel isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} title={`Cart (${cartCount})`}>
                {cart.length === 0 ? (
                    <div className="flex flex-col h-[50vh] justify-center items-center text-[#777] space-y-6">
                        <div className="p-8 rounded-full border border-dashed border-[#CCC] flex items-center justify-center bg-white">
                            <CartIcon className="w-6 h-6 text-[#CCC]" />
                        </div>
                        <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-[#1A1A1A]">Your cart is empty</p>
                        <Link to="/category/men" onClick={() => setIsCartOpen(false)} className="text-[10px] font-bold text-[#9B4819] uppercase tracking-widest border-b border-[#9B4819]">
                            Start Shopping
                        </Link>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {cart.map((item, idx) => {
                            const itemName = item.product?.name || item.name || 'Product';
                            const itemImage = item.product?.imageUrl || item.product?.image || item.image || '';
                            const itemSize = item.variant?.size || item.size || '-';
                            const itemPrice = item.variant?.price || item.product?.price || item.price || 0;
                            const itemQty = item.quantity || 1;
                            return (
                                <motion.div
                                    initial={{ opacity: 0, x: 20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: idx * 0.05 }}
                                    key={item.cartId || item.id || idx}
                                    className="flex gap-4 p-3 bg-white border border-[#E5E5E5] group"
                                >
                                    <div className="w-16 h-20 bg-[#F5F5F5] overflow-hidden">
                                        <img src={itemImage} alt={itemName} className="w-full h-full object-cover" />
                                    </div>
                                    <div className="flex-1 flex flex-col justify-between py-1">
                                        <div>
                                            <h4 className="text-xs font-bold text-[#1A1A1A] uppercase">{itemName}</h4>
                                            <p className="text-[10px] text-[#777] font-medium uppercase mt-1">Size: {itemSize} / Qty: {itemQty}</p>
                                        </div>
                                        <div className="flex justify-between items-end">
                                            <span className="text-xs font-bold text-[#1A1A1A]">₹ {itemPrice * itemQty}</span>
                                            <button onClick={() => removeFromCart(item.cartId || item.id)} className="text-[9px] font-bold text-red-500 uppercase hover:underline">Remove</button>
                                        </div>
                                    </div>
                                </motion.div>
                            );
                        })}
                    </div>
                )}
                <div className="mt-auto border-t border-[#E5E5E5] pt-6 sticky bottom-0 bg-white pb-4">
                    <div className="flex justify-between items-end mb-4 px-1">
                        <span className="text-[10px] font-bold text-[#777] tracking-widest uppercase">Subtotal</span>
                        <span className="text-xl font-black text-[#1A1A1A] tracking-tighter">₹ {cartTotal}</span>
                    </div>
                    <Link to="/checkout/address" onClick={() => setIsCartOpen(false)}>                        <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        disabled={cart.length === 0}
                        className="w-full bg-[#1A1A1A] hover:bg-[#9B4819] text-white font-bold py-3 text-xs uppercase tracking-widest transition-all"
                    >
                        Checkout
                    </motion.button>
                    </Link>
                </div>
            </SidePanel >
        </>
    );
};

export default Navbar;